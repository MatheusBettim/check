package com.example.gssaude.model

import com.example.gssaude.R


object Theme {
    var currentTheme = R.style.Theme_GSSaude

    private var ACTUAL = R.style.Theme_GSSaude
    private var NEW = R.style.variantTheme

    fun switchTheme() {
        currentTheme = when (currentTheme) {
            ACTUAL -> NEW
            NEW -> ACTUAL
            else -> -1
        }
    }
}