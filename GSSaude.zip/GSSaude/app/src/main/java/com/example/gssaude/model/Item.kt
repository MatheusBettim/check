package com.example.gssaude.model

data class Item(
    val peso : Double,
    val altura: Double
)
