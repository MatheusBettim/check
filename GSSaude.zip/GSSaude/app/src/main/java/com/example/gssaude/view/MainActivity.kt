
package com.example.gssaude

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import com.example.gssaude.model.Theme

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(Theme.currentTheme)
        setContentView(R.layout.activity_main)
        val btnTheme = findViewById<Button>(R.id.btnTheme)

        btnTheme.setOnClickListener {
            Theme.switchTheme()
            recreate()
        }
    }

    fun onBtnIMCClick(view: View) {
        val intent = Intent(this, CalculoIMCActivity::class.java)
        startActivity(intent)
    }

    fun onBtnNews(view: View) {
        val intent = Intent(this, NewsActivity::class.java)
        startActivity(intent)
    }

    fun onBtnAPI(view: View) {
        val intent = Intent(this, APIActivity::class.java)
        startActivity(intent)
    }

}
