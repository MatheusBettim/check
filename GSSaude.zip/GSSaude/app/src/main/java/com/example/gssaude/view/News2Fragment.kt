package com.example.gssaude

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.gssaude.databinding.FragmentNews2Binding

class News2Fragment : Fragment() {

    private lateinit var bind : FragmentNews2Binding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_news2, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bind = FragmentNews2Binding.bind(view)

        bind.btnNext2.setOnClickListener {
            findNavController().navigate(R.id.action_news2Fragment_to_news3Fragment)
        }
    }
}