package com.example.gssaude

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.gssaude.databinding.ActivityCalculoImcBinding
import com.example.gssaude.model.Constantes
import com.example.gssaude.model.Constantes.LISTA_IMC
import com.example.gssaude.model.Constantes.IMC_BASE
import com.example.gssaude.model.Item
import com.example.gssaude.model.Theme
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type

class CalculoIMCActivity : AppCompatActivity() {

    lateinit var bind : ActivityCalculoImcBinding
    private val adapter = ItemListaAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = ActivityCalculoImcBinding.inflate(layoutInflater)
        setTheme(Theme.currentTheme)
        setContentView(bind.root)

        val tarefas = getTarefas()
        bind.RecyclerMain.layoutManager = LinearLayoutManager(this)
        bind.RecyclerMain.adapter = adapter
        adapter.setList(
            tarefas)

        bind.btnAdd.setOnClickListener {
            val peso = bind.peso.text.toString().toDouble()
            val altura = bind.altura.text.toString().toDouble()
            tarefas.add(Item(peso, altura))
            saveList(tarefas)

            bind.RecyclerMain.layoutManager = LinearLayoutManager(this)
            bind.RecyclerMain.adapter = adapter
            adapter.setList(
                tarefas)
            saveList(tarefas)
        }
        bind.btnRemoveAll.setOnClickListener {
            adapter.setList(mutableListOf())
            saveList(mutableListOf())
        }
    }

    fun saveList(listTarefas:List<Item>){
        val listJson = Gson().toJson(listTarefas)
        val sharedPreferences = getSharedPreferences(IMC_BASE, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString(Constantes.LISTA_IMC, listJson)
        editor.apply()
    }

    fun getTarefas() : MutableList<Item> {
        val shared = getSharedPreferences(IMC_BASE, Context.MODE_PRIVATE)
        val jsonLista = shared.getString(LISTA_IMC, null)
        if (jsonLista == null) {
            return mutableListOf()
        } else {
            val type: Type = object : TypeToken<MutableList<Item>>() {}.type
            val listaTarefas = Gson().fromJson<MutableList<Item>>(jsonLista, type)
            return listaTarefas
        }
    }
    fun onBtnHomeClick(view: View) {
        val intent = Intent(this, CalculoIMCActivity::class.java)
        startActivity(intent)
    }
}