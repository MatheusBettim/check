package com.example.gssaude

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.gssaude.databinding.ItemListBinding
import com.example.gssaude.model.Item


class ItemListaAdapter() :
    RecyclerView.Adapter<ItemListaAdapter.ItemLineViewHolder>() {

    private val items: MutableList<Item> = mutableListOf()

    class ItemLineViewHolder(val itemHolder: ItemListBinding) :
        RecyclerView.ViewHolder(itemHolder.root) {

        fun bind(item: Item) {
            val imcValue = (item.peso / (item.altura * item.altura))
            itemHolder.imcResult.text = "${imcValue}"
        }
    }
        override fun getItemCount(): Int = items.size

        override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
        ):ItemLineViewHolder = ItemLineViewHolder(
                ItemListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            )

        override fun onBindViewHolder(holder: ItemLineViewHolder, position: Int) {
            holder.bind(items[position])

            holder.itemHolder.btnRemove.setOnClickListener {
                removeItem(items[position])
            }
        }

        fun setList(newItems: List<Item>) {
            items.clear()
            items.addAll(newItems)
            notifyDataSetChanged()
        }

        fun removeItem(removed: Item) {
            val removedIndex = items.indexOf(removed)
            items.remove(removed)
            notifyItemRemoved(removedIndex)
            notifyItemRangeChanged(removedIndex, items.size)
        }

}
