package com.example.gssaude.model

object Constantes {
    const val IMC_BASE = "IMC"
    const val LISTA_IMC = "LIST_IMC"
}